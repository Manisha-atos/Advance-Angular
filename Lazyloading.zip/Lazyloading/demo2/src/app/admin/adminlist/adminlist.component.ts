import { Component } from '@angular/core';
console.log('admin list loaded')
@Component({
  selector: 'app-adminlist',
  templateUrl: './adminlist.component.html',
  styleUrls: ['./adminlist.component.css']
})
export class AdminlistComponent {

}
