import { Routes } from "@angular/router";
import { Test1Component } from "./test1/test1.component";


export const APP_ROUTES: Routes = [
    
            {path:'test1',component:Test1Component},
            
            
        ];
        export class AppRoutingModule { }
    
