import { NgModule } from '@angular/core';
import { RouterModule, RouterStateSnapshot, Routes, TitleStrategy } from '@angular/router';
import { Test1Component } from './test1/test1.component';
import { Test2Component } from './test2/test2.component';


const routes: Routes = [
  {path:'test1',component:Test1Component},
  {path:'test2',component:Test2Component},
  {path:'admin',
  loadChildren: () => import('./admin/admin.module')
  .then(mod => mod.AdminModule)
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  // providers: [
  //   {provide: TitleStrategy, useClass: AppRoutingModule},
  // ]
})
export class AppRoutingModule  {
  //extends TitleStrategy
  // override updateTitle(snapshot: RouterStateSnapshot): void {
  //       const title = this.buildTitle(snapshot);
  //       console.log('update called')
  //       if (title != undefined) {
         
  //              document.title=`My Application | ${title}`
  //              console.log(title)
  //       } else {
  //         document.title=`Angular 14 App`;
  //     }
  //   }

 }
