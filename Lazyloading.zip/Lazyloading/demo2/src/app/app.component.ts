import { Component } from '@angular/core';
import { Test1Component } from './test1/test1.component';

@Component({
  selector: 'app-root', 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CompDemo';
}
