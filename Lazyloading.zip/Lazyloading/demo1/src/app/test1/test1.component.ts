import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Test2Component } from '../test2/test2.component';
console.log('test1 called')
@Component({
  selector: 'app-test1',
  standalone:true,
  imports:[CommonModule,Test2Component],
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.css']
})
export class Test1Component {

}
