import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RedDirective } from '../red.directive';
console.log('directive demo called')
@Component({
  selector: 'app-directivedemo',
  standalone: true,
  imports: [CommonModule,RedDirective],
  templateUrl: './directivedemo.component.html',
  styleUrls: ['./directivedemo.component.css']
})
export class DirectivedemoComponent {

}
