import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Test1Component } from './test1/test1.component';
import { Test2Component } from './test2/test2.component';
import { PipedemoComponent } from './pipedemo/pipedemo.component';


const routes: Routes = [
  {path:'test1',component:Test1Component},
  {path:'test2',component:Test2Component},
  {path:'pipedemo',component:PipedemoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
