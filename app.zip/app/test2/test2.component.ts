import { CommonModule, formatNumber } from '@angular/common';
import { Component } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { RedDirective } from '../red.directive';
import { Test3Component } from '../test3/test3.component';
@Component({
  selector: 'app-test2',
  standalone:true,
imports:[CommonModule,FormsModule,RedDirective,Test3Component],
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.css']
})
export class Test2Component {

}
