import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Test2Component } from './test2/test2.component';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-root',
 

  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Demo1';
}
