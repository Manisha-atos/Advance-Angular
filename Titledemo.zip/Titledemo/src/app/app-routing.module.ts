import { NgModule } from '@angular/core';
import { RouterModule, RouterStateSnapshot, Routes, TitleStrategy } from '@angular/router';
import { Test1Component } from './test1/test1.component';
import { Test2Component } from './test2/test2.component';

import { Title } from '@angular/platform-browser';

const routes: Routes = [
  {path:'test1',component:Test1Component,title:'Welcome to test1 componenet'},
  {path:'test2',component:Test2Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [
    {
      provide: TitleStrategy, useClass: AppRoutingModule},
  ]
})
export class AppRoutingModule  extends TitleStrategy {
  constructor(private readonly title: Title) {
      super();
  }
  override updateTitle(snapshot: RouterStateSnapshot): void {
    const title = this.buildTitle(snapshot);
    console.log('update called')
    if (title != undefined) {
     
           document.title=`My Application | ${title}`
           this.title.setTitle(`My Application | ${title}`);
           console.log(title)
    } else {
      document.title=`Angular 14 App`;
      this.title.setTitle(`My Application `);
  }
}
}
