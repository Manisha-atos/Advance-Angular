import { Component } from '@angular/core';
import { Test3Component } from '../test3/test3.component';

@Component({
  selector: 'app-test2',
  standalone:true,
  imports:[Test3Component],
  templateUrl: './test2.component.html',
  styleUrls: ['./test2.component.css']
})
export class Test2Component {

}
