import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-test1',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './test1.component.html',
  styleUrls: ['./test1.component.css']
})
export class Test1Component {
  title="Welcome to Extended developer diagnostics demo"
  age:any=22

}
