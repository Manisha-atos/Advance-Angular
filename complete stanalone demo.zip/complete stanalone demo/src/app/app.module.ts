import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LoginComponent } from './login/login.component';
import { Test2Component } from './test2/test2.component';
import { DirectivedemoComponent } from './directivedemo/directivedemo.component';
import { RedDirective } from './red.directive';
import { FormsModule } from '@angular/forms';
import { Test1Component } from './test1/test1.component';

@NgModule({
  declarations: [
    AppComponent,
    
    
   
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,

   DirectivedemoComponent
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
