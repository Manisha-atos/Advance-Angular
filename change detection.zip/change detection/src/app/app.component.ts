import { Component ,OnInit} from '@angular/core';
//import { BehaviorSubject } from 'rxjs/BehaviorSubject'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  title = 'changedemo';
  p1: any;
  p:any;
  fname:any;
  age:any;

  //data: any;
  ngOnInit(): void {
      this.p1 = {
          firstname: 'Manisha',
          lastname:'Mane'          
      };
      this.p={counter:1}
      this.fname="Sam"
      this.age=22
    
  }
  changeName() {
    this.p1.firstname = 'Foo';
    this.p1= {firstname:this.p1.firstname,lastname:this.p1.lastname};
    console.log(this.p1.firstname);
}
changeText()
{
  this.fname="David"
}


increment()
{
  this.p.counter++;
  console.log(this.p.counter);
  //we are changing refernce variable 
  this.p={counter:++this.p.counter};

}

 
}
