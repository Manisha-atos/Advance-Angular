import { Component,Input,ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-changecomp',
  templateUrl: './changecomp.component.html',
    changeDetection:ChangeDetectionStrategy.OnPush 
})
export class ChangecompComponent {
  @Input() person:any="";
  @Input ()  data1:any=22;
  //data1 is object and counter is property 
}
