import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChangecompComponent } from './changecomp.component';

describe('ChangecompComponent', () => {
  let component: ChangecompComponent;
  let fixture: ComponentFixture<ChangecompComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ChangecompComponent]
    });
    fixture = TestBed.createComponent(ChangecompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
